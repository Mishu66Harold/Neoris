describe('template spec', () => {
  it('passes', () => {
    // 1. Visitar la página de SauceDemo
    cy.visit('https://www.saucedemo.com/')

    // 2. Ingresar las credenciales y hacer login
    cy.get('#user-name').type('standard_user') // Ingresar nombre de usuario
    cy.get('#password').type('secret_sauce') // Ingresar contraseña
    cy.get('#login-button').click() // Hacer clic en el botón de login

    // 3. Agregar productos al carrito
    cy.get('#add-to-cart-sauce-labs-backpack').click() // Agregar "Sauce Labs Backpack"
    cy.get('#add-to-cart-sauce-labs-bike-light').click() // Agregar "Sauce Labs Bike Light"

    // 4. Ir al carrito
    cy.get('.shopping_cart_link').click() // Hacer clic en el carrito

    // 5. Verificar que los productos estén en el carrito (2 productos)
    cy.get('.cart_item').should('have.length', 2) // Verificar que haya 2 productos en el carrito

    // 6. Proceder al checkout
    cy.get('#checkout').click() // Hacer clic en "Checkout"

    // 7. Completar el formulario de checkout
    cy.get('#first-name').type('MISHELL') // Ingresar el primer nombre
    cy.get('#last-name').type('Araujo') // Ingresar el apellido
    cy.get('#postal-code').type('170105') // Ingresar el código postal

    // 8. Continuar con el proceso de checkout
    cy.get('#continue').click() // Hacer clic en "Continue" para pasar al siguiente paso

    // 9. Finalizar la compra
    cy.get('#finish').click() // Hacer clic en "Finish" para completar la compra

    // 10. Volver a la página de productos
    cy.get('#back-to-products').click() // Hacer clic en "Back to Products" para regresar
  })
})